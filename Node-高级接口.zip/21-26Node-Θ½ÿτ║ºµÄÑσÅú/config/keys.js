module.exports = {
  mongoURI: '写你自己的链接地址',
  secretOrKey: 'secret'
};
