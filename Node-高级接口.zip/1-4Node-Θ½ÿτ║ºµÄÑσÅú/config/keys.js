module.exports = {
  mongoURI: 'mongodb://test:test123@ds231725.mlab.com:31725/devconnector'
};
